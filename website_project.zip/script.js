const nicheMap = {
  general: ['life','instagood','photooftheday','picoftheday','love'],
  tamil: ['tamil','chennaigram','tamilnadu','tamillove','tamilmusic'],
  music: ['music','instamusic','newmusic','musician','songwriter'],
  politics: ['politics','news','elections','opinion','india'],
  travel: ['travel','wanderlust','travelgram','instatravel','vacation'],
  fitness: ['fitness','gym','workout','fitlife','health'],
  tech: ['tech','ai','machinelearning','startup','innovation']
};
function pick(arr,n){const out=[];const copy=arr.slice();while(out.length<n&&copy.length){const i=Math.floor(Math.random()*copy.length);out.push(copy.splice(i,1)[0]);}return out;}
function generateCaption(niche,keywords,tone){const kw=keywords.length?keywords.join(' • '):'';const base={Casual:[`${kw} — just enjoying the moment.`,`Vibes: ${kw}.`],Funny:[`${kw} and still smiling.`,`When ${kw} surprises you.`],Inspirational:[`Chase the moment. ${kw}`,`Small steps, big dreams. ${kw}`],Promotional:[`Check this out: ${kw} — link in bio!`,`New drop: ${kw}. DM for collab.`]};const arr=base[tone]||base.Casual;return arr[Math.floor(Math.random()*arr.length)];}
function buildHashtags(niche,keywords,includePopular,limit30){const tags=[];if(keywords.length){keywords.forEach(k=>{const clean=k.trim().replace(/[^\w\s]/g,'').replace(/\s+/g,'');if(clean)tags.push(clean.toLowerCase());});}const nicheTags=nicheMap[niche]||nicheMap.general;tags.push(...pick(nicheTags,6));if(includePopular)tags.push(...pick(['instagood','photooftheday','love','explore','trending'],3));const unique=[...new Set(tags)].map(t=>'#'+t);if(limit30)return unique.slice(0,30).join(' ');return unique.join(' ');}
document.getElementById('generate').addEventListener('click',()=>{const niche=document.getElementById('niche').value;const keywords=(document.getElementById('keywords').value||'').split(',').map(s=>s.trim()).filter(Boolean);const tone=document.getElementById('tone').value;const includePopular=document.getElementById('includePopular').checked;const limit30=document.getElementById('limit30').checked;document.getElementById('caption').value=generateCaption(niche,keywords,tone);document.getElementById('hashtags').value=buildHashtags(niche,keywords,includePopular,limit30);});
Array.from(document.querySelectorAll('.copy')).forEach(btn=>{btn.addEventListener('click',()=>{const target=document.getElementById(btn.dataset.target);target.select();document.execCommand('copy');btn.textContent='Copied!';setTimeout(()=>btn.textContent='Copy '+(btn.dataset.target==='caption'?'Caption':'Hashtags'),1500);});});